using MediatR;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Teknorix.JobsApi.Application.Jobs;
using Teknorix.JobsApi.Application.Jobs.Commands;
using Teknorix.JobsApi.Application.Jobs.Queries;

namespace Teknorix.JobsApi.WebApi.Controllers;

[ApiController]
[Route(""/api/v1/jobs"")]
public class JobsController : ControllerBase
{
    private readonly IMediator _mediator;
    public JobsController(IMediator mediator) => _mediator = mediator;

    /// <summary>Create a job</summary>
    [HttpPost]
    [Authorize(Roles = ""Admin"")]
    public async Task<IActionResult> Create([FromBody] JobCreateDto dto)
    {
        var id = await _mediator.Send(new CreateJobCommand(dto.Title, dto.Description, dto.LocationId, dto.DepartmentId, dto.ClosingDate));
        var location = Url.Action(nameof(GetById), new { id });
        return Created(location!, location);
    }

    /// <summary>Update a job</summary>
    [HttpPut(""{id:int}"")]
    [Authorize(Roles = ""Admin"")]
    public async Task<IActionResult> Update(int id, [FromBody] JobUpdateDto dto)
    {
        var ok = await _mediator.Send(new UpdateJobCommand(id, dto.Title, dto.Description, dto.LocationId, dto.DepartmentId, dto.ClosingDate));
        return ok ? Ok() : NotFound();
    }

    /// <summary>List jobs with paging/filtering</summary>
    [HttpPost(""../jobs/list"")]
    [AllowAnonymous]
    public async Task<ActionResult<JobListResponse>> List([FromBody] JobListRequest req)
        => await _mediator.Send(new ListJobsQuery(req.Q, req.PageNo, req.PageSize, req.LocationId, req.DepartmentId));

    /// <summary>Get job details</summary>
    [HttpGet(""{id:int}"")]
    [AllowAnonymous]
    public async Task<IActionResult> GetById(int id)
    {
        var result = await _mediator.Send(new GetJobDetailsQuery(id));
        return result is null ? NotFound() : Ok(result);
    }
}
